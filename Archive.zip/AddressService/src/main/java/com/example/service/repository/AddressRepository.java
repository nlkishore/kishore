package com.example.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.service.entity.Address;

@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {
	
	@Query(nativeQuery = true, value="select a.aid, a.lane1, a.lane2, a.city, a.pin "
			+ "from employee e join AddressMaster a on e.id = a.empid where a.empid=:id")
	
	public Address findAddressByEmployeeId(@Param("id") int id);

}
