package com.example.service.services;

import com.example.service.entity.Address;

public interface AddressService {
	
	public Address  getEmployeeAddressBasedonId(int id);

}
