package com.example.service.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.entity.Address;
import com.example.service.repository.AddressRepository;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepository repo;

	@Override
	public Address getEmployeeAddressBasedonId(int id) {

		return repo.findAddressByEmployeeId(id);
	}

}
