package com.example.service.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.services.AddressService;

import com.example.service.entity.Address;
import com.example.service.responses.AddressResponse;

@RestController
@RequestMapping("/address/")
public class AddressController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private AddressService serv;
	
	@GetMapping("/{id}")
	public ResponseEntity<AddressResponse> getById(@PathVariable int id) {
		Address add=serv.getEmployeeAddressBasedonId(id);
		AddressResponse resp = modelMapper.map(add, AddressResponse.class);
		
		//return ResponseEntity.status(HttpStatus.OK).body(add);
		
		return ResponseEntity.status(HttpStatus.OK).body(resp);
	
	}

}
