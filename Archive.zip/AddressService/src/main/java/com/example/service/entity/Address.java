package com.example.service.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name="AddressMaster")
public class Address {
	@Id
	@GeneratedValue(strategy  = GenerationType.IDENTITY )
	private int aid;
	private String lane1;
	private String lane2;
	private String City;
	private String pin;
}
