package com.example.service.entity;

import lombok.*;
import jakarta.persistence.*;

@Getter
@Setter
@Entity
@Table(name="employee")

public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(nullable=false)
	private String name;
	
	@Column(nullable=false)
	private int age;
	
	@Column(nullable=false)
	private String baselocation;
	
	@Column(nullable=false)
	private String designation;
	

}
