package com.example.service.responses;

import lombok.*;

@Getter
@Setter
public class AddressResponse {
	
	private int aid;
	private String lane1;
	private String lane2;
	private String city;
	private String pin;

}
