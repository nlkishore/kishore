package com.example.service.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.service.entity.Employee;
import com.example.service.responses.AddressResponse;
import com.example.service.responses.EmployeeResponse;
import com.example.service.services.EmployeeService;

@RestController
@RequestMapping("/employees/")
public class EmployeeController {
	
	
	
	@Autowired
	private RestTemplate restobj;
	
	@Autowired
	private ModelMapper modelMapper; 
 
	@Autowired
	private EmployeeService serv;
	
	@Value("${addressservice.base.url}")
	private String BaseURL;
	
	
	@GetMapping("/{id}")
	public ResponseEntity<EmployeeResponse> GetById(@PathVariable int id) {
		
		
		Employee emp = serv.getEmployeeBasedOnId(id);
		EmployeeResponse resp=modelMapper.map(emp,EmployeeResponse.class);
		
		//AddressResponse address = restobj.getForObject("http://localhost:8081/"+id, AddressResponse.class);
		
		AddressResponse address= restobj.getForObject(BaseURL+ "/address/"+id, AddressResponse.class);
		
		resp.setAddress(address);
		
		return ResponseEntity.status(HttpStatus.OK).body(resp);
				
	}
	
}


