package com.example.service.services;

import com.example.service.entity.Employee;

public interface EmployeeService {

	public Employee getEmployeeBasedOnId(int id);
}
