public class TestString {
    public static void main(String[] args){
        String name = "Kishore";
        System.out.println(" Name is "+name);
        System.out.println("TestString.main");
    }
}
