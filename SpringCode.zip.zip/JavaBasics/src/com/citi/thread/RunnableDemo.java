package com.citi.thread;

class MyRunnable implements Runnable
{
    @Override
    public void run() {
        for(int i=1;i<=10;i++)
        {
            System.out.println(i);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
public class RunnableDemo {

    public static void main(String[] args) {
        MyRunnable mr=new MyRunnable();
        Thread t1=new Thread(mr);
        t1.start();

        Thread t2=new Thread(mr);
        t2.start();

    }

}