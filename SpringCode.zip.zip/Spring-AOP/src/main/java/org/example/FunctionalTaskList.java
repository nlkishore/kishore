package org.example;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class FunctionalTaskList {

    public void print(){
        System.out.println("Document Printed ...");

    }

    public void scan(){
        System.out.println("Document scanned ...");

    }
}
