package org.example;

import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;
import org.hibernate.transform.Transformers;

import java.util.*;

public class Demo {

    public static Session GetSession()
    {
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Employee.class)
                .buildSessionFactory();
        return factory.openSession();
    }

    public static void Insert()
    {
        try {
            Session session=GetSession();
            Employee emp=new Employee();
            emp.setName("Steve");
            emp.setAge(29);
            emp.setDesignation("IT-Senior-Dev");


            session.beginTransaction();
            session.save(emp);
            session.getTransaction().commit();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static void Update()
    {
        try
        {
            Session session=GetSession();
            session.beginTransaction();
            Employee emp=session.get(Employee.class, 3);
            emp.setDesignation("IT-Deployment-AWS");

            session.update(emp);
            session.getTransaction().commit();
            session.close();

        }
        catch(Exception ex)
        {

        }
    }

    public static void Delete()
    {
        try
        {
            Session session=GetSession();
            session.beginTransaction();
            Employee emp=session.get(Employee.class, 3);


            session.remove(emp);
            session.getTransaction().commit();
            session.close();

        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static void GetData()
    {
        try {
            Session session=GetSession();
            List<Employee> Emps=session.createNativeQuery("select * from Employees")
                    .setResultTransformer(Transformers.aliasToBean(Employee.class))
                    .getResultList();
            for(Employee emp:Emps)
            {
                System.out.println(emp.getId());
                System.out.println(emp.getName());
                System.out.println(emp.getDesignation());
                System.out.println("-----------------------------------");
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static void GetAllRecords()
    {
        try
        {
            Session session=GetSession();
            session.beginTransaction();
            HibernateCriteriaBuilder cb=session.getCriteriaBuilder();
            CriteriaQuery<Employee> cq= cb.createQuery(Employee.class);
            Root<Employee> root=cq.from(Employee.class);
            CriteriaQuery<Employee> all=cq.select(root);

            List<Employee> Emps=session.createQuery(all).getResultList();

            for(Employee emp:Emps)
            {
                System.out.println(emp.getId());
                System.out.println(emp.getName());
                System.out.println(emp.getDesignation());
                System.out.println("-----------------------------------");
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    public static void main(String[] args) {

        Insert();
    }

}
