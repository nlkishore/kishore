package org.example;

import java.sql.*;
import java.util.*;

public class DBConnectivity {

    public static Connection getConnection() throws SQLException
    {
        String dburl="jdbc:mysql://localhost:3306/StoreDB";
        String username="Kishore";
        String pwd="Kish1381"; //orcl
        return DriverManager.getConnection(dburl,username,pwd);
    }
    public static void Insert() throws SQLException
    {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter Name:");
        String _name=sc.nextLine();

        System.out.println("Enter Age:");
        int _age=sc.nextInt();

        System.out.println("Enter Designation:");
        String _designation=sc.next();

        Connection conn=getConnection();

        if(conn!=null && !conn.isClosed())
        {
            System.out.println("Connected!");
            PreparedStatement stmt=conn.prepareStatement
                    ("insert into Users(name,age,designation)values(?,?,?)");
            stmt.setString(1, _name);
            stmt.setInt(2, _age);
            stmt.setString(3, _designation);
            int Rows=stmt.executeUpdate();
            System.out.println(Rows+" Record(s) Inserted Successfully!");
            conn.close();
        }
        else
        {
            System.out.println("Not Connected!");
        }


    }

    public static void Update() throws SQLException
    {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter Id:");
        int _id=sc.nextInt();

        System.out.println("Enter Updated Name:");
        String _name=sc.next();

        System.out.println("Enter Updated Age:");
        int _age=sc.nextInt();

        System.out.println("Enter Updated Designation:");
        String _designation=sc.next();

        Connection conn=getConnection();

        if(conn!=null && !conn.isClosed())
        {
            System.out.println("Connected!");
            PreparedStatement stmt=conn.prepareStatement
                    ("update Users set name=?,age=?,designation=? where id=?");
            stmt.setString(1, _name);
            stmt.setInt(2, _age);
            stmt.setString(3, _designation);
            stmt.setInt(4, _id);
            int Rows=stmt.executeUpdate();
            System.out.println(Rows+" Record(s) Updated Successfully!");
            conn.close();
        }
        else
        {
            System.out.println("Not Connected!");
        }


    }

    public static void GetData() throws SQLException
    {
        Connection conn=getConnection();

        if(conn!=null && !conn.isClosed())
        {
            System.out.println("Connected!");
            PreparedStatement stmt=conn.prepareStatement("select * from Users");
            ResultSet rs=stmt .executeQuery();
            while(rs.next()) {
                System.out.println("Name:"+rs.getString("name")+"     Age:"+rs.getInt("age")+"      Designation:"+rs.getString("designation"));
            }
            conn.close();
        }

    }

    public static void GetTotalRows() throws SQLException
    {
        Connection conn=getConnection();

        if(conn!=null && !conn.isClosed())
        {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select count(*) from Users");
            rs.next();
            int RowCount=rs.getInt(1);
            System.out.println("Total Rows : "+RowCount);
            conn.close();
        }

    }

    public static void Delete() throws SQLException
    {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter Id:");
        int _id=sc.nextInt();

        Connection conn=getConnection();

        if(conn!=null && !conn.isClosed())
        {
            System.out.println("Connected!");
            PreparedStatement stmt=conn.prepareStatement
                    ("delete from Users where id=?");
            stmt.setInt(1, _id);
            int Rows=stmt.executeUpdate();
            System.out.println(Rows+" Record(s) Deleted Successfully!");
            conn.close();
        }
        else
        {
            System.out.println("Not Connected!");
        }


    }

    public static void main(String[] args) throws SQLException {
        Scanner sc=new Scanner(System.in);
        boolean x=true;
        while(x)
        {
            System.out.println(" Enter \n 1.Add\n 2.Update\n 3.Delete\n 4.Get User Data\n 0.Exit");
            int n=sc.nextInt();
            switch(n)
            {
                case 1: Insert();break;
                case 2: Update();break;
                case 3: Delete();break;
                case 4: GetData();break;
                case 0: x=false;break;
                default: System.out.println("Wrong Input!");break;
            }
        }
    }
}
