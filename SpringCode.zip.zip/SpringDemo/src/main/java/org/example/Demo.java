package org.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {

    public static void main(String[] args)
    {
       // ApplicationContext factory=new ClassPathXmlApplicationContext("spring.xml");
        ApplicationContext factory=new ClassPathXmlApplicationContext("Spring-anotation.xml");
        //Bank obj=(Bank)factory.getBean("bankclass");
        Bank obj=(Bank)factory.getBean("HDFC");
        //obj.GetROI();
        System.out.println(obj);

        obj=(Bank)factory.getBean("CITI");
        //obj.GetROI();
        System.out.println(obj);
    }

}
