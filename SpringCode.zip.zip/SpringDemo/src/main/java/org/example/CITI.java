package org.example;

import org.springframework.stereotype.Component;

@Component
public class CITI implements  Bank{
    private double ROI;
    private String countryName;

    public CITI(double ROI, String countryName) {
        this.ROI = ROI;
        this.countryName = countryName;
    }

    public CITI(){
        super();
    }
    @Override
    public String toString() {
        return "CITI{" +
                "ROI=" + ROI +
                ", counteyName='" + countryName + '\'' +
                '}';
    }

    public  void GetROI(){
        System.out.println("This is from CITI Class " +ROI);
    }
}
