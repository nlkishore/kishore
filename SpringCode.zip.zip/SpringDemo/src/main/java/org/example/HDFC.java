package org.example;

import org.springframework.stereotype.Component;

@Component
public class HDFC implements Bank{
    private double ROI;
    private String countryName;

    public HDFC(double ROI, String countryName) {
        this.ROI = ROI;
        this.countryName = countryName;
    }

    public HDFC(){
        super();
    }
    @Override
    public String toString() {
        return "HDFC{" +
                "ROI=" + ROI +
                ", counteyName='" + countryName + '\'' +
                '}';
    }

    public  void GetROI(){
        System.out.println("This is from HDFC Class "+ROI);
    }
}
