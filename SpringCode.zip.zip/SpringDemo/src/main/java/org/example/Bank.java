package org.example;

public interface Bank {
    void GetROI();
}
