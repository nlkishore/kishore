package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProductDAO {
    private final JdbcTemplate jdbcTemplate;
    @Autowired
    public ProductDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void Add(Product prod){
        String query = "insert into Products(id,name,price)values(?,?,?)";
        int count = jdbcTemplate.update(query,prod.getId(),prod.getName(),prod.getPrice());
        System.out.println("Number of records inserted "+count);
    }

    public List<Product> GetProducts()
    {
        String sqlquery="select * from products";
        List<Product> prods= jdbcTemplate.query(sqlquery,new ProductRowMapper());
        System.out.println("---------------------------------");
        System.out.println("Rows Available:"+prods.size());
        System.out.println("---------------------------------");
        return prods;
    }
    public void Update(Product prod)
    {
        String query="update products set name=?,price=? where id=?";
        int _rows=jdbcTemplate.update(query,prod.getName(),prod.getPrice(),prod.getId());
        System.out.println(_rows+" Record(s) Updated Successfully!");
    }
    public void Delete(int id)
    {
        String query="delete from products where id=?";
        int _rows=jdbcTemplate.update(query,id);
        System.out.println(_rows+" Record(s) Deleted Successfully!");
    }

}
