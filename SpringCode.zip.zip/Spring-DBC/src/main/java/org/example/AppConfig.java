package org.example;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class AppConfig
{

    @Bean
    public DataSource datasource(){
        DriverManagerDataSource   datasource = new DriverManagerDataSource();
        datasource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        datasource.setUrl("jdbc:mysql://localhost:3306/StoreDB");
        datasource.setUsername("Kishore");
        datasource.setPassword("Kish1381");//orcl
        return datasource;
    }
    @Bean
    public ProductDAO getProductDAO(){
        return new ProductDAO(new JdbcTemplate(datasource()));
    }

}
