package org.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {

    public static void Insert()
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);

        Product prod=new Product();
        prod.setId(104);
        prod.setName("Samsung S23 FE");
        prod.setPrice(85000);

        dao.Add(prod);
    }

    public static void GetData()
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);

        List<Product> products= dao.GetProducts();
        for(Product prod:products)
        {
            System.out.println("Id:"+prod.getId());
            System.out.println("Name:"+prod.getName());
            System.out.println("Price:"+prod.getPrice());
            System.out.println("--------------------------------------");
        }
    }
    public static void Update()
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);

        Product prod=new Product();
        prod.setId(104);
        prod.setName("Samsung S23 FE");
        prod.setPrice(99000);

        dao.Update(prod);
    }

    public static void Delete()
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
        dao.Delete(103);
    }

    public static void main(String[] args) {
       // Insert();
        GetData();
      //  Delete();
      //  Update();
    }
}