package org.example;


import org.springframework.stereotype.Component;

@Component
public class Department {
    public Department(int did, String name) {
        Did = did;
        Name = name;
    }

    public int getDid() {
        return Did;
    }

    public void setDid(int did) {
        Did = did;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    private int Did;
    private String Name;

}
