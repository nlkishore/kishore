package org.example;

import org.springframework.stereotype.Component;

@Component
public class Employee {
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public double getSalary() {
        return Salary;
    }

    public void setSalary(double salary) {
        Salary = salary;
    }

    private int Id;

    public Employee(int id, String name, double salary, Department department) {
        Id = id;
        Name = name;
        Salary = salary;
        this.department = department;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    private String Name;
    private double Salary;

    private Department department;
}
